<?php
class Database {
    private $db;

    public function __construct() {
        $this->db = mysqli_connect('localhost', 'root', '', 'restaurant_reservations');
        
        if (mysqli_connect_errno()) {
            die("Failed to connect to MySQL: " . mysqli_connect_error());
        }
    }

    public function addCustomer($name, $contact) {
        $query = "INSERT INTO customers (name, contact) 
                  VALUES ('$name', '$contact')";
        return mysqli_query($this->db, $query);
    }

    public function updateCustomer($id, $name, $contact) {
        $query = "UPDATE customers SET name='$name', contact='$contact' WHERE id='$id'";
        return mysqli_query($this->db, $query);
    }

    public function deleteCustomer($id) {
        $query = "DELETE FROM customers WHERE id='$id'";
        return mysqli_query($this->db, $query);
    }

    public function addReservation($customerId, $reservationTime, $numberOfGuests, $specialRequests) {
        $query = "INSERT INTO reservations (customer_id, time, guest, request) 
                  VALUES ('$customerId', '$reservationTime', '$numberOfGuests', '$specialRequests')";
        return mysqli_query($this->db, $query);
    }

    public function updateReservation($id, $customerId, $reservationTime, $numberOfGuests, $specialRequests) {
        $query = "UPDATE reservations SET customer_id='$customerId', time='$reservationTime', guest='$numberOfGuests', request='$specialRequests' WHERE id='$id'";
        return mysqli_query($this->db, $query);
    }

    public function deleteReservation($id) {
        $query = "DELETE FROM reservations WHERE id='$id'";
        return mysqli_query($this->db, $query);
    }

    public function addCustomerPreferences($customer_id, $seat, $dish, $note) {
        $query = "INSERT INTO preferences (customer_id, seat, dish, note) 
                  VALUES ('$customer_id', '$seat', '$dish', '$note')";
        return mysqli_query($this->db, $query);
    }

    public function updateCustomerPreferences($id, $customer_id, $seat, $dish, $note) {
        $query = "UPDATE preferences SET customer_id='$customer_id', seat='$seat', dish='$dish', note='$note' WHERE id='$id'";
        return mysqli_query($this->db, $query);
    }

    public function getCustomerPreferences($customer_id) {
        $query = "SELECT *, P.id, C.name AS Customer FROM preferences P INNER JOIN customers C ON P.customer_id = C.id WHERE P.customer_id = '$customer_id'";
        
        $result = mysqli_query($this->db, $query);
        
        if (mysqli_num_rows($result) > 0) {
            return mysqli_fetch_assoc($result);
        } else {
            return false;
        }
    }
}
?>