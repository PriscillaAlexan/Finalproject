<?php

session_start();

include 'ReservationController.php';

$reservationController = new ReservationController();

if (isset($_POST['create'])) {
    $reservationController->addReservation();
}

if(isset($_POST['edit'])) {
    $reservationController->updateReservation();                  
}

if(isset($_POST['delete'])){
    $reservationController->deleteReservation();  
}

if (isset($_POST['create_preferences'])) {
    $reservationController->addCustomerPreferences();
}

if(isset($_POST['edit_preferences'])) {
    $reservationController->updateCustomerPreferences();                  
}

if(isset($_POST['search'])) {
    $reservationController->getCustomerPreferences();                  
}

?>