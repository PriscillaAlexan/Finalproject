<?php

session_start();

include 'CustomerController.php';

$customerController = new CustomerController();
$db = mysqli_connect('localhost', 'root', '', 'restaurant_reservations');

if (isset($_POST['create'])) {
    $name = $_POST ['name'];
    $contact = $_POST ['contact'];

    $contactquery = "SELECT * FROM customers WHERE contact='$contact'";
    $contactquery_run = mysqli_query($db, $contactquery);

    if($contactquery_run){
      foreach($contactquery_run as $row)
      {
        $contactcheck = $row ['contact'];
        }
    }
    else
    {

    }	

  	if($contactcheck == $contact){
      $_SESSION['message'] = "This contact already in the system!";
      $_SESSION['msg_type'] = "danger";
      header('Location: ' . $_SERVER['HTTP_REFERER']);	
    }
    else{
        $customerController->addCustomer();
  	}
}

if(isset($_POST['edit'])) {

    $id = $_POST['update_customerid'];
    $name = $_POST ['name'];
    $contact = $_POST ['contact'];

    $contactquery = "SELECT * FROM customers WHERE contact='$contact' AND id!='$id'";
    $contactquery_run = mysqli_query($db, $contactquery);

    if($contactquery_run){
      foreach($contactquery_run as $row)
      {
        $contactcheck = $row ['contact'];
        }
    }
    else
    {

    }

    if($contactcheck == $contact){
        $_SESSION['message'] = "That contact already using in the system!";
        $_SESSION['msg_type'] = "danger";
        header('Location: ' . $_SERVER['HTTP_REFERER']);	
    }
    else{
        $customerController->updateCustomer();
    }             
      
}

if(isset($_POST['delete'])){
    $customerController->deleteCustomer();
  
}

?>