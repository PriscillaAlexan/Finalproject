<?php

session_start();

$db = mysqli_connect('localhost', 'root', '', 'restaurant_reservations');

if (isset($_POST['login_btn'])) {

	$email = $_POST['email'];
	$password = md5 ($_POST['password']);		

    $query = "SELECT * FROM users WHERE (email='$email') AND password='$password'";
    $results = mysqli_query($db, $query);

    if (mysqli_num_rows($results) == 1) {
        $logged_in_user = mysqli_fetch_assoc($results);
        $_SESSION['user'] = $logged_in_user;
        header('location: home.php');			
    }
    else {
        $_SESSION['message'] = "Invalid email or password";
        $_SESSION['msg_type'] = "danger";
        header("location: login.php");
    }		
}
?>
