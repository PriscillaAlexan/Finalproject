<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CheckIn - System</title>

    <link href="./include/style.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

    <!-- font-awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Owl carousel -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>
<body class="bg-light" style="overflow-x: hidden;">
    <nav class="navbar navbar-expand-lg navbar-light bg-color sticky-top">
        <div class="container-fluid d-flex justify-content-start">            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link text-light" aria-current="page" href="./home.php"><i class="fa fa-home"></i> Home</a>
                </li>
                <li class="nav-item">
                <a class="nav-link text-dark" href="./restaurant.php">Restaurant</a>
                </li>
            </ul>
            </div>
        </div>

        <div class="container-fluid justify-content-end"> 
            <div>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="logout.php">Log Out</a>                    
                    </li>
                </ul>
            </div>                      
        </div>        
    </nav><br>   
    <?php include('./loginconn.php');?>

<!-- Create New Account Modal -->
<div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
      
        <h5 class="modal-title" id="exampleModalLabel">Add New User</h5>
        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>      
      <form action="userconn.php" method="POST">
        <div class="modal-body">                    
          <div class="form-group">
            <label>Enter First and Last Name</label>
            <input type="text" name="name" class="form-control" placeholder="Enter Name" required>                              
          </div><br>
          <div class="form-group">
            <label>Enter Email Address</label>
            <input type="text" name="email" class="form-control" placeholder="Enter Email" required>                              
          </div>
          <br>
          <div class="form-group">
            <label>Enter Password</label>
            <input type="password" name="password" id="addpassword" class="form-control" placeholder="Enter Password" required>                    
          </div><br>
          <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="cmpassword" id="cmpassword" class="form-control" placeholder="Enter Same Password" required>                    
          </div>
          <span id='passwordcheck'></span>
          <br>              
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" style="width: 100px;">Close</button>
          <button type="submit" name="create" class="btn btn-success passwordvalid" style="width: 100px;">Save</button>                               
        </div>
      </form>
    </div>    
  </div>
</div>
<!-- End Of Create New Account Modal -->

<!-- Edit user modal -->
<div class="modal fade" id="edituser" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">      
        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="userconn.php" method="POST">
        <div class="modal-body">
          <input type="hidden" name="update_userid" id="update_userid">
          <div class="form-group">
            <label>Enter First and Last Name</label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Enter Name" required>                              
          </div><br>
          <div class="form-group">
            <label>Enter Email Address</label>
            <input type="text" name="email" id="email" class="form-control" placeholder="Enter Email" required>                              
          </div>
          <br>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal" style="width: 80px;">Close</button>
          <button type="submit" name="edit" class="btn btn-primary rounded-pill" style="width: 80px;">Update</button>     
        </div>
     </form>
    </div>    
  </div>
</div>
<!-- end of edit user modal -->

<!-- Delete User Modal -->
<div class="modal fade" id="deleteuser" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="userconn.php" method="POST">
        <div class="modal-body">
            <input type="hidden" name="delete_userid" id="delete_userid">            
            Do you want to delete this data?   
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal" style="width: 80px;">No</button>
            <button type="submit" name="delete" class="btn btn-danger rounded-pill" style="width: 80px;">Yes</button>
        </div>
     </form>
    </div>    
  </div>
</div>

<!-- New Customer Modal -->
<div class="modal fade" id="addCustomer" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
      
        <h5 class="modal-title" id="exampleModalLabel">Add New Customer</h5>
        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>      
      <form action="customerconn.php" method="POST">
        <div class="modal-body">                    
          <div class="form-group">
            <label>Enter Customer Name</label>
            <input type="text" name="name" class="form-control" placeholder="Enter Customer Name" required>                              
          </div><br>
          <div class="form-group">
            <label>Enter Contact Number</label>
            <input type="text" name="contact" class="form-control" placeholder="Enter Contact" required>                              
          </div>
          <br>            
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" style="width: 100px;">Close</button>
          <button type="submit" name="create" class="btn btn-success" style="width: 100px;">Save</button>                               
        </div>
      </form>
    </div>    
  </div>
</div>

<!-- Edit customer modal -->
<div class="modal fade" id="editcustomer" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">      
        <h5 class="modal-title" id="exampleModalLabel">Edit Customer</h5>        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="customerconn.php" method="POST">
        <div class="modal-body">
          <input type="hidden" name="update_customerid" id="update_customerid">
          <div class="form-group">
            <label>Enter Customer Name</label>
            <input type="text" name="name" id="customer_name" class="form-control" placeholder="Enter Customer Name" required>                              
          </div><br>
          <div class="form-group">
            <label>Enter Contact Number</label>
            <input type="text" name="contact" id="customer_contact" class="form-control" placeholder="Enter Contact" required>                              
          </div>
          <br>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal" style="width: 80px;">Close</button>
          <button type="submit" name="edit" class="btn btn-primary rounded-pill" style="width: 80px;">Update</button>     
        </div>
     </form>
    </div>    
  </div>
</div>
<!-- end of edit customer modal -->

<!-- Delete customer Modal -->
<div class="modal fade" id="deletecustomer" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Customer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="customerconn.php" method="POST">
        <div class="modal-body">
            <input type="hidden" name="delete_customerid" id="delete_customerid">            
            Do you want to delete this data?   
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal" style="width: 80px;">No</button>
            <button type="submit" name="delete" class="btn btn-danger rounded-pill" style="width: 80px;">Yes</button>
        </div>
     </form>
    </div>    
  </div>
</div>

<?php
if(isset($_SESSION['message'])): ?>
<div class="alert alert-<?=$_SESSION['msg_type']?>">
    <?php
    echo $_SESSION['message'];
    unset($_SESSION['message']);
    ?>
</div>
<?php endif ?>
<?php
if (!isset($_SESSION['user'])) {
  echo "<script>window.location.href = './login.php';</script>";
  exit();
}

$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'restaurant_reservations');
$id = $_SESSION['user']['id'];

$query = "SELECT * FROM users WHERE id='$id'";
$query_run = mysqli_query($connection, $query);
if($query_run){
    foreach($query_run as $row)
    {
?>
<h5 class="text-center text-muted">Welcome <?php echo $row ['name'];?></h5><br>
<?php
        }
}
else
{
    echo "NO record found";
    }

?>


<div class="row justify-content-center">
    <div class="col-4">
        <div class="d-flex justify-content-center">
            <button title="Add new user" class="btn btn-none border border-success" data-bs-toggle="modal" data-bs-target="#add" style="width: 140px; height: 140px;"><i class="fa fa-plus"></i> Add New User</button>
        </div>
    </div>
    <div class="col-4">
        <div>
        <h6 class="text-center"><strong>System Users</strong></h6>
        <?php
            $limit = 15;  
            if (isset($_GET["page"])) {
            $page  = $_GET["page"]; 
            } 
            else{ 
            $page=1;
            };  
            $start_from = ($page-1) * $limit;

            $query = "SELECT * FROM users ORDER BY id LIMIT $start_from, $limit";
            $query_run = mysqli_query($connection, $query);
        ?>
        <table class="table table-light table-hover table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
            </thead>
            <?php

            if($query_run){
                foreach($query_run as $row)
                {
            ?>
            <tbody>
            <tr>
            <td><?php echo $row ['id'];?></td>
            <td><?php echo $row ['name'];?></td>
            <td><?php echo $row ['email'];?></td>
            <td class="text-end">
                <button title="edit" class="btn btn-nome rounded-pill edituserbtn" data-bs-toggle="modal" data-bs-target="#edituser" style="width: 30px;"><i class="fa fa-pencil-square"></i></button>                 
                <button title="delete" class="btn btn-none rounded-pill deleteuserbtn" data-bs-toggle="modal" data-bs-target="#deleteuser" style="width: 30px;"><i class="fa fa-trash"></i></button>             
            </td>
            </tr>              
            </tbody>
            <?php
                    }
            }
            else
            {
                echo "NO record found";
            }

            ?> 
        </table>
        <?php  
            $result_db = mysqli_query($connection, "SELECT COUNT(id) FROM users");
            $row_db = mysqli_fetch_row($result_db);  
            $total_records = $row_db[0];  
            $total_pages = ceil($total_records / $limit); 
            
            $pagLink = "<ul class='pagination'>";  
            for ($i=1; $i<=$total_pages; $i++) {
                        $pagLink .= "<li class='page-item'><a class='page-link' href='home.php?page=".$i."'>".$i."</a></li>";	
            }
            echo $pagLink . "</ul>";  
        ?>
        </div>
    </div>
</div><br>
<div class="row justify-content-center">
    <div class="col-4">
        <div class="d-flex justify-content-center">
            <button title="Add new Customer" class="btn btn-none border border-success" data-bs-toggle="modal" data-bs-target="#addCustomer" style="width: 140px; height: 140px;"><i class="fa fa-plus"></i> Add New Customer</button>
        </div>
    </div>
    <div class="col-4">
        <div>
        <h6 class="text-center"><strong>Customers</strong></h6>
        <?php
            $limit = 15;  
            if (isset($_GET["page"])) {
            $page  = $_GET["page"]; 
            } 
            else{ 
            $page=1;
            };  
            $start_from = ($page-1) * $limit;

            $query = "SELECT * FROM customers ORDER BY id LIMIT $start_from, $limit";
            $query_run = mysqli_query($connection, $query);
        ?>
        <table class="table table-light table-hover table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Action</th>
            </tr>
            </thead>
            <?php

            if($query_run){
                foreach($query_run as $row)
                {
            ?>
            <tbody>
            <tr>
            <td><?php echo $row ['id'];?></td>
            <td><?php echo $row ['name'];?></td>
            <td><?php echo $row ['contact'];?></td>
            <td class="text-end">
                <button title="edit" class="btn btn-nome rounded-pill editcustomerbtn" data-bs-toggle="modal" data-bs-target="#editcustomer" style="width: 30px;"><i class="fa fa-pencil-square"></i></button>                 
                <button title="delete" class="btn btn-none rounded-pill deletecustomerbtn" data-bs-toggle="modal" data-bs-target="#deletecustomer" style="width: 30px;"><i class="fa fa-trash"></i></button>             
            </td>
            </tr>              
            </tbody>
            <?php
                    }
            }
            else
            {
                echo "NO record found";
            }

            ?> 
        </table>
        <?php  
            $result_db = mysqli_query($connection, "SELECT COUNT(id) FROM customers");
            $row_db = mysqli_fetch_row($result_db);  
            $total_records = $row_db[0];  
            $total_pages = ceil($total_records / $limit); 
            
            $pagLink = "<ul class='pagination'>";  
            for ($i=1; $i<=$total_pages; $i++) {
                        $pagLink .= "<li class='page-item'><a class='page-link' href='home.php?page=".$i."'>".$i."</a></li>";	
            }
            echo $pagLink . "</ul>";  
        ?>
        </div>
    </div>
</div>
    

<!-- Bootstrap Javascript-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>  
<script>
$('#addpassword, #cmpassword').on('keyup', function () { 
    
  if ($('#addpassword').val() == $('#cmpassword').val()) {
    $('#passwordcheck').html('Passwords Matching').css('color', 'green');
    $(".passwordvalid").attr('disabled', false);
  }
  else if($('#cmpassword').val() == ''){
    $('#passwordcheck').html('');
  }
  else { 
    $('#passwordcheck').html('Passwords Not Matching').css('color', 'red');
    $(".passwordvalid").attr('disabled', true);
  }
  if ($('#addpassword').val() == '' && $('#cmpassword').val() == '') {
    $('#passwordcheck').html('');
  }  
});

$(document).ready(function(){
    $('.edituserbtn').on('click', function(){
        

      $tr = $(this).closest('tr');

      var data = $tr.children("td").map(function() {
          return $(this).text();      

      }).get();

      console.log(data);

      $('#update_userid').val(data[0]);
      $('#name').val(data[1]);
      $('#email').val(data[2]);
    });
});

$(document).ready(function(){
    $('.deleteuserbtn').on('click', function(){
        

      $tr = $(this).closest('tr');

      var data = $tr.children("td").map(function() {
          return $(this).text();      

      }).get();

      console.log(data);

      $('#delete_userid').val(data[0]);
    });
});

$(document).ready(function(){
    $('.editcustomerbtn').on('click', function(){
        

      $tr = $(this).closest('tr');

      var data = $tr.children("td").map(function() {
          return $(this).text();      

      }).get();

      console.log(data);

      $('#update_customerid').val(data[0]);
      $('#customer_name').val(data[1]);
      $('#customer_contact').val(data[2]);
    });
});

$(document).ready(function(){
    $('.deletecustomerbtn').on('click', function(){
        

      $tr = $(this).closest('tr');

      var data = $tr.children("td").map(function() {
          return $(this).text();      

      }).get();

      console.log(data);

      $('#delete_customerid').val(data[0]);
    });
});
</script>
</body>
</html>