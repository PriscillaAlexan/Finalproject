<?php
include 'Database.php';

class CustomerController {
    private $db;
    public function __construct() {
        $this->db = new Database();
    }

    public function addCustomer() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $contact = $_POST['contact'];

            if ($this->db->addCustomer($name, $contact)) {
 
                $_SESSION['message'] = "Customer Registered!";
                $_SESSION['msg_type'] = "success";

                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            } else {
                $_SESSION['message'] = "Failed to add customer.";
                $_SESSION['msg_type'] = "danger";
                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            }
        } else {
            include 'home.php';
        }
    }

    public function updateCustomer() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['update_customerid'];
            $name = $_POST['name'];
            $contact = $_POST['contact'];

            if ($this->db->updateCustomer($id, $name, $contact)) {
 
                $_SESSION['message'] = "Customer has been updated!";
                $_SESSION['msg_type'] = "warning";

                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            } else {
                $_SESSION['message'] = "Failed to update customer.";
                $_SESSION['msg_type'] = "danger";
                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            }
        } else {
            include 'home.php';
        }
    }

    public function deleteCustomer() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['delete_customerid'];

            if ($this->db->deleteCustomer($id)) {
 
                $_SESSION['message'] = "Customer has been deleted!";
                $_SESSION['msg_type'] = "danger";

                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            } else {
                $_SESSION['message'] = "Failed to delete customer.";
                $_SESSION['msg_type'] = "danger";
                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            }
        } else {
            include 'home.php';
        }
    }
}
?>