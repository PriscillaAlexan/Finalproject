<?php

session_start();

$db = mysqli_connect('localhost', 'root', '', 'restaurant_reservations');

if (isset($_POST['create'])) {
    $name = $_POST ['name'];
    $email = $_POST ['email'];
    $password = $_POST ['password'];
    $cmpassword = $_POST ['cmpassword'];
    $password = md5($password);

    $emailquery = "SELECT * FROM users WHERE email='$email'";
    $emailquery_run = mysqli_query($db, $emailquery);

    if($emailquery_run){
      foreach($emailquery_run as $row)
      {
        $emailcheck = $row ['email'];
        }
    }
    else
    {

    }	

  	if($emailcheck == $email){
      $_SESSION['message'] = "That email already using in the system!";
      $_SESSION['msg_type'] = "danger";
      header('Location: ' . $_SERVER['HTTP_REFERER']);	
    }
    else{
      $query = "INSERT INTO users (name, email, password) 
          VALUES ('$name', '$email', '$password')";
      $results = mysqli_query($db, $query);
      $_SESSION['message'] = "Account created!";
      $_SESSION['msg_type'] = "success";
      header('Location: ' . $_SERVER['HTTP_REFERER']);
  	}
}

if(isset($_POST['edit'])) {

    $id = $_POST['update_userid'];
    $name = $_POST ['name'];
    $email = $_POST ['email'];

    $emailquery = "SELECT * FROM users WHERE email='$email' AND id!='$id'";
    $emailquery_run = mysqli_query($db, $emailquery);

    if($emailquery_run){
      foreach($emailquery_run as $row)
      {
        $emailcheck = $row ['email'];
        }
    }
    else
    {

    }

    if($emailcheck == $email){
        $_SESSION['message'] = "That email already using in the system!";
        $_SESSION['msg_type'] = "danger";
        header('Location: ' . $_SERVER['HTTP_REFERER']);	
    }
    else{

        $query = "UPDATE users SET name='$name', email='$email' WHERE id='$id'";
        $results = mysqli_query($db, $query);

        $_SESSION['message'] = "User has been updated!";
        $_SESSION['msg_type'] = "warning";

        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }             
      
}

if(isset($_POST['delete'])){
    $id = $_POST['delete_userid'];
    
    $query = "DELETE FROM users WHERE id='$id'";
    $results = mysqli_query($db, $query);
  
    $_SESSION['message'] = "User has been deleted!";
    $_SESSION['msg_type'] = "danger";
  
    header('Location: ' . $_SERVER['HTTP_REFERER']);
  
}

?>