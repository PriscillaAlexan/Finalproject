<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CheckIn - System</title>

    <link href="./include/style.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

    <!-- font-awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Owl carousel -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>
<body class="bg-light" style="overflow-x: hidden;">
    <nav class="navbar navbar-expand-lg navbar-light bg-color sticky-top">
        <div class="container-fluid d-flex justify-content-start">            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link text-dark" aria-current="page" href="./home.php"><i class="fa fa-home"></i> Home</a>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light" href="./restaurant.php">Restaurant</a>
                </li>
            </ul>
            </div>
        </div>

        <div class="container-fluid justify-content-end"> 
            <div>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="logout.php">Log Out</a>                    
                    </li>
                </ul>
            </div>                      
        </div>        
    </nav><br>   
    <?php include('./loginconn.php');?>

<?php
if(isset($_SESSION['message'])): ?>
<div class="alert alert-<?=$_SESSION['msg_type']?>">
    <?php
    echo $_SESSION['message'];
    unset($_SESSION['message']);
    ?>
</div>
<?php endif ?>
<?php
if (!isset($_SESSION['user'])) {
  echo "<script>window.location.href = './login.php';</script>";
  exit();
}
?>

<!-- Add New Reservation Modal -->
<div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
      
        <h5 class="modal-title" id="exampleModalLabel">Add New Reservation</h5>
        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>      
      <form action="reservationconn.php" method="POST">
        <div class="modal-body">
          <div class="form-group col-md-6">
            <label for="customer_id" class="font-weight-bold">Select Customer</label>
              <?php
              $connection = mysqli_connect("localhost","root","");
              $db = mysqli_select_db($connection,'restaurant_reservations');

              $query = "SELECT * FROM customers ORDER BY id";
              $query_run = mysqli_query($connection, $query);
              ?>
            <select name="customer_id" class="form-control" required>
              <option value="" selected disabled>Select A Customer From Here</option>
              <?php

              if($query_run){
                foreach($query_run as $row)
              {
              ?>
              <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?> (<?php echo $row['contact']; ?>)</option>
              <?php
                }
              }
              else
              {
                echo "NO record found";
              }

              ?>
            </select>                                        
          </div><br>                    
          <div class="form-group col-md-6">
            <label>Enter Reservation Time</label>
            <input type="time" name="time" class="form-control" placeholder="Enter Reservation Time" required>                              
          </div><br>
          <div class="form-group">
            <label>Enter Number Of Guests</label>
            <input type="text" name="guest" class="form-control" placeholder="Enter Number Of Guests" required>                              
          </div>
          <br>  
          <div class="form-group">
            <label>Enter Special Requests</label>
            <input type="text" name="request" class="form-control" placeholder="Enter Special Requests">                              
          </div>
          <br>              
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" style="width: 100px;">Close</button>
          <button type="submit" name="create" class="btn btn-success passwordvalid" style="width: 100px;">Save</button>                               
        </div>
      </form>
    </div>    
  </div>
</div>
<!-- End Of Add New Reservation Modal -->

<!-- Edit Reservation modal -->
<div class="modal fade" id="editreservation" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">      
        <h5 class="modal-title" id="exampleModalLabel">Edit Reservation</h5>        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="reservationconn.php" method="POST">
        <div class="modal-body">
          <input type="hidden" name="update_reservationid" id="update_reservationid">
          <div class="form-group col-md-6">
            <label for="customer_id" class="font-weight-bold">Select Customer</label>
              <?php
              $connection = mysqli_connect("localhost","root","");
              $db = mysqli_select_db($connection,'restaurant_reservations');

              $query = "SELECT * FROM customers ORDER BY id";
              $query_run = mysqli_query($connection, $query);
              ?>
            <select name="customer_id" id="customer_id" class="form-control" required>
              <option value="" selected disabled>Select A Customer From Here</option>
              <?php

              if($query_run){
                foreach($query_run as $row)
              {
              ?>
              <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?> (<?php echo $row['contact']; ?>)</option>
              <?php
                }
              }
              else
              {
                echo "NO record found";
              }

              ?>
            </select>                                        
          </div><br>                    
          <div class="form-group col-md-6">
            <label>Enter Reservation Time</label>
            <input type="time" name="time" id="time" class="form-control" placeholder="Enter Reservation Time" required>                              
          </div><br>
          <div class="form-group">
            <label>Enter Number Of Guests</label>
            <input type="text" name="guest" id="guest" class="form-control" placeholder="Enter Number Of Guests" required>                              
          </div>
          <br>  
          <div class="form-group">
            <label>Enter Special Requests</label>
            <input type="text" name="request" id="request" class="form-control" placeholder="Enter Special Requests">                              
          </div>
          <br>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal" style="width: 80px;">Close</button>
          <button type="submit" name="edit" class="btn btn-primary rounded-pill" style="width: 80px;">Update</button>     
        </div>
     </form>
    </div>    
  </div>
</div>
<!-- end of edit Reservation modal -->

<!-- Delete Reservation Modal -->
<div class="modal fade" id="deletereservation" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Reservation</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="reservationconn.php" method="POST">
        <div class="modal-body">
            <input type="hidden" name="delete_reservationid" id="delete_reservationid">            
            Do you want to delete this data?   
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal" style="width: 80px;">No</button>
            <button type="submit" name="delete" class="btn btn-danger rounded-pill" style="width: 80px;">Yes</button>
        </div>
     </form>
    </div>    
  </div>
</div>

<div class="row justify-content-center">
    <div class="col-4">
        <div class="d-flex justify-content-center">
            <button title="Add new reservation" class="btn btn-none border border-success" data-bs-toggle="modal" data-bs-target="#add" style="width: 140px; height: 140px;"><i class="fa fa-plus"></i> Add New Reservation</button>
        </div>
    </div>
</div> 
<div class="row justify-content-center m-4">
    <div>
        <div>
        <h6 class="text-center"><strong>Reservations</strong></h6>
        <?php
            $limit = 15;  
            if (isset($_GET["page"])) {
            $page  = $_GET["page"]; 
            } 
            else{ 
            $page=1;
            };  
            $start_from = ($page-1) * $limit;

            $query = "SELECT *, R.id, C.name AS Customer FROM reservations R INNER JOIN customers C ON R.customer_id = C.id ORDER BY R.id DESC LIMIT $start_from, $limit";
            $query_run = mysqli_query($connection, $query);
        ?>
        <table class="table table-light table-hover table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Reservation Time</th>
                <th>Number Of Guests</th>
                <th>Special Request</th>
                <th>Action</th>
            </tr>
            </thead>
            <?php

            if($query_run){
                foreach($query_run as $row)
                {
            ?>
            <tbody>
            <tr>
            <td><?php echo $row ['id'];?></td>
            <td><?php echo $row ['Customer'];?></td>
            <td><?php echo $row ['time'];?></td>
            <td><?php echo $row ['guest'];?></td>
            <td><?php echo $row ['request'];?></td>
            <td style="display:none;"><?php echo $row ['customer_id'];?></td>
            <td class="text-end">
                <button title="edit" class="btn btn-nome rounded-pill editreservationbtn" data-bs-toggle="modal" data-bs-target="#editreservation" style="width: 30px;"><i class="fa fa-pencil-square"></i></button>                 
                <button title="delete" class="btn btn-none rounded-pill deletereservationbtn" data-bs-toggle="modal" data-bs-target="#deletereservation" style="width: 30px;"><i class="fa fa-trash"></i></button>             
            </td>
            </tr>              
            </tbody>
            <?php
                    }
            }
            else
            {
                echo "NO record found";
            }

            ?> 
        </table>
        <?php  
            $result_db = mysqli_query($connection, "SELECT COUNT(id) FROM reservations");
            $row_db = mysqli_fetch_row($result_db);  
            $total_records = $row_db[0];  
            $total_pages = ceil($total_records / $limit); 
            
            $pagLink = "<ul class='pagination'>";  
            for ($i=1; $i<=$total_pages; $i++) {
                        $pagLink .= "<li class='page-item'><a class='page-link' href='home.php?page=".$i."'>".$i."</a></li>";	
            }
            echo $pagLink . "</ul>";  
        ?>
        </div>
    </div>
</div>

<div class="row justify-content-center m-4">
    <div>
        <div>
        <h6 class="text-center"><strong>Dining Preferences</strong></h6>
        <?php
            $limit = 15;  
            if (isset($_GET["page"])) {
            $page  = $_GET["page"]; 
            } 
            else{ 
            $page=1;
            };  
            $start_from = ($page-1) * $limit;

            $query = "SELECT * FROM customers ORDER BY id LIMIT $start_from, $limit";
            $query_run = mysqli_query($connection, $query);
        ?>
        <table class="table table-light table-hover table-bordered">
            <thead>
            <tr>
                <th>Customer ID</th>
                <th>Customer Name</th>
                <th>Customer Contact</th>
                <th>Manage Preferences</th>
            </tr>
            </thead>
            <?php

            if($query_run){
                foreach($query_run as $row)
                {
            ?>
            <tbody>
            <tr>
            <td><?php echo $row ['id'];?></td>
            <td><?php echo $row ['name'];?></td>
            <td><?php echo $row ['contact'];?></td>
            <td>
              <a href="./preferences.php?id=<?php echo $row['id']; ?>" title="Manage" class="btn btn-nome rounded-pill" style="width: 50px;"><i class="fa fa-pencil-square"></i></a>            
            </td>
            </tr>              
            </tbody>
            <?php
                    }
            }
            else
            {
                echo "NO record found";
            }

            ?> 
        </table>
        <?php  
            $result_db = mysqli_query($connection, "SELECT COUNT(id) FROM customers");
            $row_db = mysqli_fetch_row($result_db);  
            $total_records = $row_db[0];  
            $total_pages = ceil($total_records / $limit); 
            
            $pagLink = "<ul class='pagination'>";  
            for ($i=1; $i<=$total_pages; $i++) {
                        $pagLink .= "<li class='page-item'><a class='page-link' href='home.php?page=".$i."'>".$i."</a></li>";	
            }
            echo $pagLink . "</ul>";  
        ?>
        </div>
    </div>
</div>

<div class="row justify-content-center m-4">
    <div>
      <div>
        <h6 class="text-center"><strong>Search Customer Preferences</strong></h6>
        <form action="reservationconn.php" method="POST">   
          <div class="row justify-content-center">
            <div class="form-group col-md-6 d-flex align-items-center">
              <label for="customer_id" class="mr-2">Enter Customer ID</label>&nbsp;&nbsp;
              <input type="text" name="customer_id"  
              <?php
              if (isset($_SESSION['preferences'])) { ?>
                value="<?php echo $_SESSION['preferences']['customer_id'];?>"
              <?php
              }
              ?> 
              class="form-control mr-2" placeholder="Enter Customer ID" style="flex: 1;">&nbsp;
              <button type="submit" name="search" class="btn btn-primary rounded-pill">Search</button>
            </div>
          </div>
        </form>
      </div>
    </div>
</div>
<div class="row justify-content-center m-4">
    <div>
      <div>
        <?php
        if (isset($_SESSION['preferences'])) {
        $preferences = $_SESSION['preferences'];
        ?>
        <table class="table table-light table-hover table-bordered">
          <thead>
          <tr>
            <th>Customer</th>
            <th>Seating Preference</th>
            <th>Favorite Dishes or Cuisines</th>
            <th>Special Notes</th>
          </tr>
          </thead>
          <tbody>
            <tr>
              <td><?php echo $preferences ['Customer'];?></td>
              <td><?php echo $preferences['seat'];?></td>
              <td><?php echo $preferences['dish'];?></td>
              <td><?php echo $preferences['note'];?></td>
            </tr>              
          </tbody>
          <?php
            unset($_SESSION['preferences']);
          }

          ?> 
        </table>
      </div>
    </div>
</div>

<!-- Bootstrap Javascript-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>  
<script>
  $(document).ready(function(){
    $('.editreservationbtn').on('click', function(){
        

      $tr = $(this).closest('tr');

      var data = $tr.children("td").map(function() {
          return $(this).text();      

      }).get();

      console.log(data);

      $('#update_reservationid').val(data[0]);
      $('#customer_id').val(data[5]);
      $('#time').val(data[2]);
      $('#guest').val(data[3]);
      $('#request').val(data[4]);
    });
});

$(document).ready(function(){
    $('.deletereservationbtn').on('click', function(){
        

      $tr = $(this).closest('tr');

      var data = $tr.children("td").map(function() {
          return $(this).text();      

      }).get();

      console.log(data);

      $('#delete_reservationid').val(data[0]);
    });
});
</script>
</body>
</html>