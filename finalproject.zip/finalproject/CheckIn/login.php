<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CheckIn - Login</title>

    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    
</head>

<body class="bg-light" style="overflow: hidden;">
<?php session_start();
unset($_SESSION['userid']);
unset($_SESSION['useridsearch']);
?>
<div class="row justify-content-center">
    <div class="col-4">
        <div><br><br>
            <img src="./assets/home.png" width="400" height="300">
        </div>        
    </div>
    <div class="col-4">
      <div class="container vh-100">
        <div class="row justify-content-center h-100">
          <div class="card my-auto shadow">
            <div class="text-center text-primary"><br>                    
              <h5>Login</h5><hr>                                      
            </div>
            <div class="card-body">
              <?php
              if(isset($_SESSION['message'])): ?>
              <div class="alert alert-<?=$_SESSION['msg_type']?>">
                  <?php
                  echo $_SESSION['message'];
                  unset($_SESSION['message']);
                  ?>
              </div>
              <?php endif ?>
              <form action="loginconn.php" method="post">                    
                <div class="form-group">
                    <input type="text" class="form-control" id="user" placeholder="Email address" name="email" required>
                </div><br>
                <div class="form-group">
                    <input type="password" class="form-control" id="password" placeholder="Password" name="password" required>
                </div><br>
                <button type="submit" class="btn btn-primary w-100" name="login_btn">Log In</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>

<!-- Bootstrap Javascript-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>

</body>
</html>
