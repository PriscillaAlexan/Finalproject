<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CheckIn - System</title>

    <link href="./include/style.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

    <!-- font-awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Owl carousel -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>
<body class="bg-light" style="overflow-x: hidden;">
    <nav class="navbar navbar-expand-lg navbar-light bg-color sticky-top">
        <div class="container-fluid d-flex justify-content-start">            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link text-dark" aria-current="page" href="./home.php"><i class="fa fa-home"></i> Home</a>
                </li>
                <li class="nav-item">
                <a class="nav-link text-light" href="./restaurant.php">Restaurant</a>
                </li>
            </ul>
            </div>
        </div>

        <div class="container-fluid justify-content-end"> 
            <div>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="logout.php">Log Out</a>                    
                    </li>
                </ul>
            </div>                      
        </div>        
    </nav><br>   
    <?php include('./loginconn.php');?>

<?php
if(isset($_SESSION['message'])): ?>
<div class="alert alert-<?=$_SESSION['msg_type']?>">
    <?php
    echo $_SESSION['message'];
    unset($_SESSION['message']);
    ?>
</div>
<?php endif ?>
<?php
if (!isset($_SESSION['user'])) {
  echo "<script>window.location.href = './login.php';</script>";
  exit();
}
?>

<div class="row justify-content-center m-4">
    <div>
        <div>
        <a href="./restaurant.php" class="btn btn-secondary rounded-pill mb-2">Back</a>
        <h6 class="text-center"><strong>Manage Dining Preferences</strong></h6>
        <?php
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $connection = mysqli_connect("localhost", "root", "", "restaurant_reservations");
            if (!$connection) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $customer_query = "SELECT * FROM customers WHERE id='$id'";
            $customer_query_run = mysqli_query($connection, $customer_query);

            $query = "SELECT *, P.id, C.name AS Customer FROM preferences P INNER JOIN customers C ON P.customer_id = C.id WHERE P.customer_id='$id'";
            $query_run = mysqli_query($connection, $query);

            if($customer_row = mysqli_fetch_assoc($customer_query_run)) {
                if ($row = mysqli_fetch_assoc($query_run)) {
                    ?>
                    <h6 class="mb-2">Customer: <?php echo $customer_row['name']; ?></h6>
                    <form action="reservationconn.php" method="POST"> 
                        <input type="hidden" name="update_preferencesid" value="<?php echo $row['id']; ?>">                  
                        <div class="form-group col-md-6">
                            <label>Enter Seating Preference</label>
                            <input type="text" name="seat" value="<?php echo $row['seat']; ?>" class="form-control" placeholder="Enter Seating Preference" required>                              
                        </div><br>
                        <div class="form-group col-md-6">
                            <label>Enter Favorite Dishes or Cuisines</label>
                            <input type="text" name="dish" value="<?php echo $row['dish']; ?>" class="form-control" placeholder="Enter Dishes or Cuisines" required>                              
                        </div><br>  
                        <div class="form-group col-md-6">
                            <label>Enter Special Notes</label>
                            <input type="text" name="note" value="<?php echo $row['note']; ?>" class="form-control" placeholder="Enter Special Notes">                              
                        </div>
                        <input type="hidden" name="customer_id" value="<?php echo $row['customer_id']; ?>">
                        <br>
                        <button type="submit" name="edit_preferences" class="btn btn-primary rounded-pill" style="width: 80px;">Update</button>
                    </form>
                    <?php
                } else {
                    ?>
                    <h6 class="mb-2">Customer: <?php echo $customer_row['name']; ?></h6>
                    <form action="reservationconn.php" method="POST">                   
                        <div class="form-group col-md-6">
                            <label>Enter Seating Preference</label>
                            <input type="text" name="seat" class="form-control" placeholder="Enter Seating Preference" required>                              
                        </div><br>
                        <div class="form-group col-md-6">
                            <label>Enter Favorite Dishes or Cuisines</label>
                            <input type="text" name="dish" class="form-control" placeholder="Enter Dishes or Cuisines" required>                              
                        </div><br>  
                        <div class="form-group col-md-6">
                            <label>Enter Special Notes</label>
                            <input type="text" name="note" class="form-control" placeholder="Enter Special Notes">                              
                        </div>
                        <input type="hidden" name="customer_id" value="<?php echo $id; ?>">
                        <br>
                        <button type="submit" name="create_preferences" class="btn btn-success passwordvalid" style="width: 100px;">Save</button>
                    </form>
                    <?php
                }
            }

            mysqli_close($connection);
        } else {
            echo "No ID provided.";
        }
        ?>
        </div>
    </div>
</div>

<!-- Bootstrap Javascript-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>  
</body>
</html>