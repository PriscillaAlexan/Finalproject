<?php
include 'Database.php';

class ReservationController {
    private $db;
    public function __construct() {
        $this->db = new Database();
    }

    public function addReservation() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $customerId = $_POST['customer_id'];
            $reservationTime = $_POST['time'];
            $numberOfGuests = $_POST['guest'];
            $specialRequests = $_POST['request'];

            if ($this->db->addReservation($customerId, $reservationTime, $numberOfGuests, $specialRequests)) {
 
                $_SESSION['message'] = "Reservation Recorded!";
                $_SESSION['msg_type'] = "success";

                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            } else {
                $_SESSION['message'] = "Failed to add reservation.";
                $_SESSION['msg_type'] = "danger";
                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            }
        } else {
            include 'restaurant.php';
        }
    }

    public function updateReservation() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['update_reservationid'];
            $customerId = $_POST['customer_id'];
            $reservationTime = $_POST['time'];
            $numberOfGuests = $_POST['guest'];
            $specialRequests = $_POST['request'];

            if ($this->db->updateReservation($id, $customerId, $reservationTime, $numberOfGuests, $specialRequests)) {
 
                $_SESSION['message'] = "Reservation has been updated!";
                $_SESSION['msg_type'] = "warning";

                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            } else {
                $_SESSION['message'] = "Failed to update reservation.";
                $_SESSION['msg_type'] = "danger";
                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            }
        } else {
            include 'restaurant.php';
        }
    }

    public function deleteReservation() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['delete_reservationid'];

            if ($this->db->deleteReservation($id)) {
 
                $_SESSION['message'] = "Reservation has been deleted!";
                $_SESSION['msg_type'] = "danger";

                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            } else {
                $_SESSION['message'] = "Failed to delete reservation.";
                $_SESSION['msg_type'] = "danger";
                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            }
        } else {
            include 'restaurant.php';
        }
    }

    public function addCustomerPreferences() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $customer_id = $_POST['customer_id'];
            $seat = $_POST['seat'];
            $dish = $_POST['dish'];
            $note = $_POST['note'];

            if ($this->db->addCustomerPreferences($customer_id, $seat, $dish, $note)) {
 
                $_SESSION['message'] = "Customer Preferences Recorded!";
                $_SESSION['msg_type'] = "success";

                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            } else {
                $_SESSION['message'] = "Failed to Add Customer Preferences.";
                $_SESSION['msg_type'] = "danger";
                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            }
        } else {
            include 'preferences.php';
        }
    }

    public function updateCustomerPreferences() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['update_preferencesid'];
            $customer_id = $_POST['customer_id'];
            $seat = $_POST['seat'];
            $dish = $_POST['dish'];
            $note = $_POST['note'];

            if ($this->db->updateCustomerPreferences($id, $customer_id, $seat, $dish, $note)) {
 
                $_SESSION['message'] = "Customer Preference has been updated!";
                $_SESSION['msg_type'] = "warning";

                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            } else {
                $_SESSION['message'] = "Failed to Update Customer Preferences.";
                $_SESSION['msg_type'] = "danger";
                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            }
        } else {
            include 'preferences.php';
        }
    }

    public function getCustomerPreferences() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $customer_id = $_POST['customer_id'];
    
            $preferences = $this->db->getCustomerPreferences($customer_id);
    
            if ($preferences) {
                $_SESSION['preferences'] = $preferences;
                
                header('Location: restaurant.php');
                exit();
            } else {
                $_SESSION['message'] = "Failed to Get Customer Preferences.";
                $_SESSION['msg_type'] = "danger";
                header('Location: ' . $_SERVER['HTTP_REFERER']);
                exit();
            }
        } else {
            include 'restaurant.php';
        }
    }
}
?>